#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <math.h>
#include <time.h>


//Structure declarations
struct atom {
	int atomID;
	int atom_type_id;
	char atomTYPE;
};

struct tube {
	int tubeID;
	int tubeTS;
	int moleculeTYPE;
	int num_of_atoms;
	struct atom atoms_in_tube[5];
};

struct Information {
	int tubeID;
	struct tube mytube;
};

struct tube all_tubes[3];
//Structure declarations

void* createTubes(void* args){//Tube initialization.
	for(int i=0; i<3;i++){
		all_tubes[i].tubeID = i+1;
		all_tubes[i].tubeTS = 0;
		all_tubes[i].moleculeTYPE = 0;
		all_tubes[i].num_of_atoms = 0;
	}
}

int isEmpty(int tube_num){//Checks if the tube is empty.
	return all_tubes[tube_num].num_of_atoms == 0;
}

int num_of_empty_tubes(){//Returns the number of empty tubes.
	int count = 0;
	for(int i=0;i<3;i++){
		if(all_tubes[i].num_of_atoms == 0){count++;}
	}
	return count;
}

struct atom* get_atoms_in_tube(int tube_num){//returns the atoms in the tube.
	return all_tubes[tube_num].atoms_in_tube;	
}

//If a tube is not available, assign number 9 to that tube.
int* available_for_C(){
	int* available_tubes = malloc(sizeof(int)*3);
	for(int i=0;i<3;i++){
		int C_count = 0;
		int H_count = 0;
		int O_count = 0;
		int N_count = 0;
		int size_of_tube = all_tubes[i].num_of_atoms;
		struct atom* atoms_of_tube = get_atoms_in_tube(i);
		if(size_of_tube == 0){available_tubes[i] = i;}
		else{
			for(int j=0; j<size_of_tube;j++){//Count the atoms in the tubes.					
				if (atoms_of_tube[j].atomTYPE == 'C'){C_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'H'){H_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'O'){O_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'N'){N_count++;}		
			}
		}
		//Checks if the tube is suitable for the atom
		//Conditions are determined manually
		if(N_count > 0 || H_count > 0 || C_count > 0){available_tubes[i] = 9;}
		else{available_tubes[i] = i;}
	}
	return available_tubes;
}


int* available_for_H(){
	int* available_tubes = malloc(sizeof(int)*3);
	for(int i=0;i<3;i++){
		int C_count = 0;
		int H_count = 0;
		int O_count = 0;
		int N_count = 0;
		int size_of_tube = all_tubes[i].num_of_atoms;
		struct atom* atoms_of_tube = get_atoms_in_tube(i);
		if(size_of_tube == 0){available_tubes[i] = i;}
		else{
			for(int j=0; j<size_of_tube;j++){//Count the atoms in the tubes.					
				if (atoms_of_tube[j].atomTYPE == 'C'){C_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'H'){H_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'O'){O_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'N'){N_count++;}		
			}
		}
		//Checks if the tube is suitable for the atom
		//Conditions are determined manually
		if(N_count > 0 && O_count > 0){available_tubes[i] = 9;}
		else if(C_count > 0){available_tubes[i] = 9;}
		else if(H_count > 2){available_tubes[i] = 9;}
		else{available_tubes[i] = i;}
	}
	return available_tubes;
}

int* available_for_O(){
	int* available_tubes = malloc(sizeof(int)*3);
	for(int i=0;i<3;i++){
		int C_count = 0;
		int H_count = 0;
		int O_count = 0;
		int N_count = 0;
		int size_of_tube = all_tubes[i].num_of_atoms;
		struct atom* atoms_of_tube = get_atoms_in_tube(i);
		if(size_of_tube == 0){available_tubes[i] = i;}
		else{
			for(int j=0; j<size_of_tube;j++){//Count the atoms in the tubes.			
				if (atoms_of_tube[j].atomTYPE == 'C'){C_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'H'){H_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'O'){O_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'N'){N_count++;}		
			}
		}
		//Checks if the tube is suitable for the atom
		//Conditions are determined manually
		if(N_count > 0 && H_count > 0){available_tubes[i] = 9;}
		else if(O_count > 1){available_tubes[i] = 9;}
		else if(H_count > 2){available_tubes[i] = 9;}
		else{available_tubes[i] = i;}
	}	
	return available_tubes;
}

int* available_for_N(){
	int* available_tubes = malloc(sizeof(int)*3);
	for(int i=0;i<3;i++){
		int C_count = 0;
		int H_count = 0;
		int O_count = 0;
		int N_count = 0;
		int size_of_tube = all_tubes[i].num_of_atoms;
		struct atom* atoms_of_tube = get_atoms_in_tube(i);
		if(size_of_tube == 0){available_tubes[i] = i;}
		else{
			for(int j=0; j<size_of_tube;j++){//Count the atoms in the tubes.					
				if (atoms_of_tube[j].atomTYPE == 'C'){C_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'H'){H_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'O'){O_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'N'){N_count++;}		
			}
		}
		//Checks if the tube is suitable for the atom
		//Conditions are determined manually
		if(O_count > 0 && H_count > 0){available_tubes[i] = 9;}
		else if(C_count > 0){available_tubes[i] = 9;}
		else if(N_count >= 1){available_tubes[i] = 9;}
		else{available_tubes[i] = i;}
	}
	return available_tubes;
}

void* best_tube(void* atom_type){
	//Run the best tube thread to decide which tube is the best one for the input atom.
	//Then, return the best tube number from thread to main function.
	//Then place the atom the the returned tube.
	int* result = malloc(sizeof(int));
	if(num_of_empty_tubes() == 3){
        *result = 0;
        pthread_exit((void*) result);
        return;
    }//If all tubes are empty, then place it into the first tube.
	int timeStamp = 1000000;
	int tube_num = 5;
	char *temp = (char *) atom_type;
	char inp_type = *temp;
	int* tubes_for_C;
	int* tubes_for_H;
	int* tubes_for_O;
	int* tubes_for_N;
	switch(inp_type){
		case 'C':			
			//Get the suitable tubes for the atom. Then, search the best tube.
			tubes_for_C = available_for_C();
					
			for(int i=0;i<3;i++){
				if(tubes_for_C[i] == 9){} //If the tube number is 9, the tube is not suitable. Pass.
				else{ 
					if(tube_num == 5 && isEmpty(tubes_for_C[i])){tube_num = tubes_for_C[i];}
					//Checks the first empty tube.
					else if(isEmpty(tubes_for_C[i])){}
					else{if(all_tubes[i].tubeTS < timeStamp){
						timeStamp = all_tubes[i].tubeTS;
						tube_num = tubes_for_C[i];
						}
					}
					//Checks the not empty, suitable and the tube with the lowest ID(highest priority)
				}
			}
			free(tubes_for_C);
			*result = tube_num;
			pthread_exit((void*) result);
			break;		
			
		case 'H':	
			//Get the suitable tubes for the atom. Then, search the best tube.		
			tubes_for_H = available_for_H();			
			for(int i=0;i<3;i++){
				if(tubes_for_H[i] == 9){}//If the tube number is 9, the tube is not suitable. Pass.
				else{ 
					if(tube_num == 5 && isEmpty(tubes_for_H[i])){tube_num = tubes_for_H[i];}
					//Checks the first empty tube.
					else if(isEmpty(tubes_for_H[i])){}
					else{if(all_tubes[i].tubeTS < timeStamp){
						timeStamp = all_tubes[i].tubeTS;
						tube_num = tubes_for_H[i];
						}
					}
					//Checks the not empty, suitable and the tube with the lowest ID(highest priority)
				}
			}
			free(tubes_for_H);
			*result = tube_num;
			pthread_exit((void*) result);
			break;		
			
		case 'O':
			//Get the suitable tubes for the atom. Then, search the best tube.
			tubes_for_O = available_for_O();			
			for(int i=0;i<3;i++){
				if(tubes_for_O[i] == 9){}//If the tube number is 9, the tube is not suitable. Pass.
				else{ 
					if(tube_num == 5 && isEmpty(tubes_for_O[i])){tube_num = tubes_for_O[i];}
					//Checks the first empty tube.
					else if(isEmpty(tubes_for_O[i])){}
					else{if(all_tubes[i].tubeTS < timeStamp){
						timeStamp = all_tubes[i].tubeTS;
						tube_num = tubes_for_O[i];
						}
					}
					//Checks the not empty, suitable and the tube with the lowest ID(highest priority)
				}

			}
			free(tubes_for_O);
			*result = tube_num;
			pthread_exit((void*) result);
			break;		
			
		case 'N':
			//Get the suitable tubes for the atom. Then, search the best tube.
			tubes_for_N = available_for_N();			
			for(int i=0;i<3;i++){
				if(tubes_for_N[i] == 9){}//If the tube number is 9, the tube is not suitable. Pass.
				else{ 
					if(tube_num == 5 && isEmpty(tubes_for_N[i])){tube_num = tubes_for_N[i];}
					//Checks the first empty tube.
					else if(isEmpty(tubes_for_N[i])){}
					else{if(all_tubes[i].tubeTS < timeStamp){
						timeStamp = all_tubes[i].tubeTS;
						tube_num = tubes_for_N[i];
						}
					}
					//Checks the not empty, suitable and the tube with the lowest ID(highest priority)
				}
			}
			free(tubes_for_N);
			*result = tube_num;
			pthread_exit((void*) result);
			break;						
	}

}

void place_atom(int tube_number, char atom_type, int atom_ID){
	for(int i=0; i<3; i++){
		if(i == tube_number){//Place the atom to the suitable tube. Then, update the variables.
			int atom_num = all_tubes[i].num_of_atoms;
			all_tubes[i].num_of_atoms++;
			all_tubes[i].atoms_in_tube[atom_num].atomTYPE = atom_type;
			all_tubes[i].atoms_in_tube[atom_num].atomID = atom_ID;
			if(all_tubes[i].num_of_atoms == 1){//If the tube is empty, update the time stamp of the tube.
				all_tubes[i].tubeTS = atom_ID;
			}
		}
	}
}

void* compound_forms(void* args){
	for(int i=0; i<3; i++){//Go over all the tubes.
		int C_count = 0;
		int H_count = 0;
		int O_count = 0;
		int N_count = 0;
		int compound = 0;
		int size_of_tube = all_tubes[i].num_of_atoms; //In a tube, go over all the atoms and count them.
		struct atom* atoms_of_tube;
		atoms_of_tube = get_atoms_in_tube(i);
		if(size_of_tube == 0){}
		else{
			for(int j=0; j<size_of_tube;j++){					
				if (atoms_of_tube[j].atomTYPE == 'C'){C_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'H'){H_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'O'){O_count++;}
				else if(atoms_of_tube[j].atomTYPE == 'N'){N_count++;}		
			}
		}
		//Create compound if requirements are satisfied and print 
		if(H_count == 2 && O_count == 1){printf("H2O is created in tube %d\n", i+1);compound++;}
		else if(C_count == 1 && O_count == 2){printf("CO2 is created in tube %d\n", i+1);compound++;}
		else if(N_count == 1 && O_count == 2){printf("NO2 is created in tube %d\n", i+1);compound++;}
		else if(N_count == 1 && H_count == 3){printf("NH3 is created in tube %d\n", i+1);compound++;}
		else{}
		
		if(compound == 1){//Clear the tube.
			for(int j=0; j<size_of_tube;j++){					
				all_tubes[i].atoms_in_tube[j].atomTYPE = ' ';	
			}
			all_tubes[i].num_of_atoms = 0;
		}

	}


}

int main (int argc, char **argv) {
	//Create variables
	pthread_t compound_thread;
	pthread_t create_tubes;
	int* return_ptr = NULL;
	int num_of_c = 20;
	int num_of_h = 20;
	int num_of_o = 20;
	int num_of_n = 20;
	int num_of_g = 100;
	int c,h,o,n,g ;
	int temp;
	//Get the inputs
	while ((temp = getopt(argc, argv, "c:h:o:n:g:")) != -1){
		switch (temp)
			{
				case 'c':
					num_of_c = atoi(optarg);
					break;	
				case 'h':
					num_of_h = atoi(optarg);
					break;	
				case 'o':
					num_of_o = atoi(optarg);
					break;	
				case 'n':
					num_of_n = atoi(optarg);
					break;	
				case 'g':
					num_of_g = atoi(optarg);
					break;
				default:
					break;
		}	
	}	
	//Get the inputs
	int total_atoms = num_of_c + num_of_h + num_of_o + num_of_n;
	pthread_create(&create_tubes,NULL,&createTubes,NULL);//Create tubes with thread.
	pthread_t best_tube_thread[total_atoms];
	srand(time(NULL));
	//Critical section of the main function starts
	for(int i = 0; i<total_atoms; i++){
		int sleep_time;
		float x;
		x = rand()/((float) RAND_MAX+1);
		sleep_time = -(log(1-x)/num_of_g);
		//Generate the sleep time as given in the HW1 manual
		int tube_number;
		int atom_indicator = rand() % 4; //C:0, H:1, O:2, N:3, generate atoms randomly
	
		switch(atom_indicator){
			case 0:
				if(num_of_c != 0){
					char atom_char = 'C';
					//Get the best tube for C atoms
					pthread_create(&best_tube_thread[i],NULL,&best_tube,(void*)&atom_char);
					pthread_join(best_tube_thread[i],(void**) &return_ptr);
					//Get the best tube for C atoms
					tube_number = *return_ptr;
					if(tube_number == 5){
					//If thread returns 5, then the best tube number is not updated.
					//Hence, there are no tubes available. Atoms will be wasted.
					printf("C with ID:%d is created\n", i+1);
					printf("C with ID:%d wasted\n", i+1);
					}
					else{
					place_atom(tube_number, 'C', i+1);
					//If thread returns other than 5, place it into the tube
					printf("C with ID:%d is created\n", i+1);
					
					}
					num_of_c--;
					//Decrease the number of atoms
				}
				else{i--;continue;}
				break;
			case 1:
				if(num_of_h != 0){
					char atom_char = 'H';
					//Get the best tube for H atoms
					pthread_create(&best_tube_thread[i],NULL,&best_tube,(void*)&atom_char);
					pthread_join(best_tube_thread[i],(void**) &return_ptr);
					tube_number = *return_ptr;
					//Get the best tube for H atoms
					if(tube_number == 5){
					//If thread returns 5, then the best tube number is not updated.
					//Hence, there are no tubes available. Atoms will be wasted.
					printf("H with ID:%d is created\n", i+1);
					printf("H with ID:%d wasted\n", i+1);
					}
					else{
					place_atom(tube_number, 'H', i+1);
					//If thread returns other than 5, place it into the tube
					printf("H with ID:%d is created\n", i+1);
					
					}
					num_of_h--;
					//Decrease the number of atoms
				}
				else{i--;continue;}
				break;
			case 2:
				if(num_of_o != 0){
					char atom_char = 'O';

					//Get the best tube for O atoms
					pthread_create(&best_tube_thread[i],NULL,&best_tube,(void*)&atom_char);
					pthread_join(best_tube_thread[i],(void**) &return_ptr);
					tube_number = *return_ptr;

					//Get the best tube for O atoms
					if(tube_number == 5){
					//If thread returns 5, then the best tube number is not updated.
					//Hence, there are no tubes available. Atoms will be wasted.
					printf("O with ID:%d is created\n", i+1);			
					printf("O with ID:%d wasted\n", i+1);
					}
					else{
					place_atom(tube_number, 'O', i+1);
					//If thread returns other than 5, place it into the tube
					printf("O with ID:%d is created\n", i+1);
					
					}
					num_of_o--;
					//Decrease the number of atoms
				}
				else{i--;continue;}
				break;
			case 3:
				if(num_of_n != 0){
					char atom_char = 'N';
					//Get the best tube for N atoms
					pthread_create(&best_tube_thread[i],NULL,&best_tube,(void*)&atom_char);
					pthread_join(best_tube_thread[i],(void**) &return_ptr);
					tube_number = *return_ptr;
					//Get the best tube for N atoms
					if(tube_number == 5){
					//If thread returns 5, then the best tube number is not updated.
					//Hence, there are no tubes available. Atoms will be wasted.					
					printf("N with ID:%d is created\n", i+1);							
					printf("N with ID:%d wasted\n", i+1);
					}
					else{
					place_atom(tube_number, 'N', i+1);
					//If thread returns other than 5, place it into the tube
					printf("N with ID:%d is created\n", i+1);
					
					}
					num_of_n--;
					//Decrease the number of atoms
				}
				else{i--;continue;}
				break;
		}
		pthread_create(&compound_thread,NULL,&compound_forms,NULL);//Check if a compound is formed in a tube with thread.
		sleep(sleep_time);//Required sleep time.
		
	}
	//Critical section of the main function ends
	
	
	free(return_ptr);				
	return 0;
}


