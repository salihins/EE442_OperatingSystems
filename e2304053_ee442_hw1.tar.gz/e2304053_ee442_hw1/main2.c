#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <semaphore.h>

//Declaration of the semaphores
sem_t C_sem;
sem_t H_sem;
sem_t O_sem;
sem_t N_sem;
sem_t H2O_sem;
sem_t CO2_sem;
sem_t NH3_sem;
sem_t NO2_sem;

//Atom ID as global variable.
int atomID=0;

void* Produce_C(void* args){//Create atom
	int semValC;
	sem_post(&C_sem);//Increase the number of semaphore of the atom
	sem_getvalue(&C_sem,&semValC);
	printf("C with ID:%d is created.\n",atomID);//Print the output	

}
void* Produce_H(void* args){//Create atom
	int semValH;
	sem_post(&H_sem);//Increase the number of semaphore of the atom
	sem_getvalue(&H_sem,&semValH);
	printf("H with ID:%d is created.\n",atomID);//Print the output
}
void* Produce_O(void* args){//Create atom
	int semValO;
	sem_post(&O_sem);//Increase the number of semaphore of the atom
	sem_getvalue(&O_sem,&semValO);
	printf("O with ID:%d is created.\n",atomID);//Print the output
}
void* Produce_N(void* args){//Create atom
	int semValN;
	sem_post(&N_sem);//Increase the number of semaphore of the atom
	sem_getvalue(&N_sem,&semValN);
	printf("N with ID:%d is created.\n",atomID);//Print the output
}
void* Composer_H2O(void* args){
	int semValH;
	int semValO;
	int semValH2O;
	sem_getvalue(&H_sem,&semValH);//Get the values of atoms in the compound to check the conditions
	sem_getvalue(&O_sem,&semValO);


	if((semValH >= 2) && (semValO >= 1)){
		//Check if necessary conditions for compound are satisfied			
		sem_wait(&H_sem);//Spend the atoms while creating compound. (Number of created atom is decreased)
		sem_wait(&H_sem);
		sem_wait(&O_sem);
		sem_post(&H2O_sem);//Create the compound. Number of compound semaphore is increased.
		sem_getvalue(&H2O_sem,&semValH2O);
		printf("H2O is generated.\n");
	}

}
void* Composer_CO2(void* args){
	int semValC;
	int semValO;
	int semValCO2;
	sem_getvalue(&C_sem,&semValC);//Get the values of atoms in the compound to check the conditions
	sem_getvalue(&O_sem,&semValO);

	if((semValC >= 1) && (semValO>=2)){
		//Check if necessary conditions for compound are satisfied			
		sem_wait(&O_sem);//Spend the atoms while creating compound. (Number of created atom is decreased)
		sem_wait(&O_sem);
		sem_wait(&C_sem);
		sem_post(&CO2_sem);//Create the compound. Number of compound semaphore is increased.
		sem_getvalue(&CO2_sem,&semValCO2);
		printf("CO2 is generated.\n");


 	}

}
void* Composer_NO2(void* args){
	int semValN;
	int semValO;
	int semValNO2;
	sem_getvalue(&N_sem,&semValN);//Get the values of atoms in the compound to check the conditions
	sem_getvalue(&O_sem,&semValO);
	//printf("N is %d, O is %d\n",semValN, semValO);


	if((semValN >= 1) && (semValO >= 2)){
		sem_wait(&O_sem);//Spend the atoms while creating compound. (Number of created atom is decreased)
		sem_wait(&O_sem);
		sem_wait(&N_sem);

		sem_post(&NO2_sem);//Create the compound. Number of compound semaphore is increased.		
		sem_getvalue(&NO2_sem,&semValNO2);
		printf("NO2 is generated.\n");

	}

}
void* Composer_NH3(void* args){
	int semValN;
	int semValH;
	int semValNH3;
	sem_getvalue(&N_sem,&semValN);//Get the values of atoms in the compound to check the conditions
	sem_getvalue(&H_sem,&semValH);
	if((semValH >= 3) && (semValN >= 1)){
		//Check if necessary conditions for compound are satisfied
		sem_wait(&H_sem);//Spend the atoms while creating compound. (Number of created atom is decreased)
		sem_wait(&H_sem);
		sem_wait(&H_sem);
		sem_wait(&N_sem);
		sem_post(&NH3_sem);//Create the compound. Number of compound semaphore is increased.	
		sem_getvalue(&NH3_sem,&semValNH3);
		printf("NH3 is generated.\n");

	}
	
}
int main (int argc, char **argv) {

	sem_init(&C_sem,0,0);
	sem_init(&H_sem,0,0);
	sem_init(&O_sem,0,0);
	sem_init(&N_sem,0,0);
	sem_init(&H2O_sem,0,0);
	sem_init(&CO2_sem,0,0);
	sem_init(&NH3_sem,0,0);
	sem_init(&NO2_sem,0,0);
	
	//Declaration of threads
	pthread_t c_thread;
	pthread_t h_thread;
	pthread_t o_thread;
	pthread_t n_thread;
	pthread_t co_thread;
	pthread_t no_thread;
	pthread_t nh_thread;
	pthread_t ho_thread;

	int m = 40;
	int num_of_c;
	int num_of_h;
	int num_of_o;
	int num_of_n;
	int num_of_g = 100;
	int c,h,o,n,g;
	int temp;

	while ((temp = getopt(argc, argv, "g:m:")) != -1){
		switch (temp)
			{
				case 'g':
					num_of_g = atoi(optarg);
					break;
				case 'm':
					m = atoi(optarg);
					break;
				default:
					break;
		}	
	}
	//Get the total atoms
	int total_atoms = m;
	//Decide on how many atoms will be generated.
	num_of_c = m/4;
	num_of_h = m/4;
	num_of_o = m/4;
	num_of_n = m/4;
	//Critical section of the main function starts
	srand(time(NULL));
	for(int i = 0; i<total_atoms; i++){
		int sleep_time;
		float x;
		x = rand()/((float) RAND_MAX+1);
		sleep_time = -(log(1-x)/num_of_g);
		//Generate the sleep time as given in the HW1 manual
		int atom_indicator = rand() % 4; //C:0, H:1, O:2, N:3, generate atoms randomly
	
		switch(atom_indicator){
			case 0:
				if(num_of_c != 0){
					pthread_create(&c_thread, NULL, &Produce_C, NULL);
					//Call the related thread to create atom.
					atomID++;
					//Increase the atom ID after creation of atom
					num_of_c--;
					pthread_join(c_thread,NULL);
					//Decrease the number of atoms
				}
				else{i--;continue;}
				break;
			case 1:
				if(num_of_h != 0){
					pthread_create(&h_thread, NULL, &Produce_H, NULL);
					//Call the related thread to create atom.
					atomID++;
					//Increase the atom ID after creation of atom
					num_of_h--;
					pthread_join(h_thread,NULL);
					//Decrease the number of atoms
				}
				else{i--;continue;}
				break;
			case 2:
				if(num_of_o != 0){
					pthread_create(&o_thread, NULL, &Produce_O, NULL);
					//Call the related thread to create atom.
					atomID++;
					//Increase the atom ID after creation of atom
					num_of_o--;
					pthread_join(o_thread,NULL);
					//Decrease the number of atoms
				}
				else{i--;continue;}
				break;
			case 3:
				if(num_of_n != 0){
					pthread_create(&n_thread, NULL, &Produce_N, NULL);
					//Call the related thread to create atom.
					atomID++;
					//Increase the atom ID after creation of atom
					num_of_n--;
					pthread_join(n_thread,NULL);
					//Decrease the number of atoms
				}
				else{i--;continue;}
				break;
		}
		//Check if compound is formed
		if(pthread_create(&co_thread, NULL, &Composer_CO2, NULL) != 0){return 1;}
		pthread_join(co_thread,NULL);

		if(pthread_create(&ho_thread, NULL, &Composer_H2O, NULL) != 0){return 1;}
		pthread_join(ho_thread,NULL);


		if(pthread_create(&no_thread, NULL, &Composer_NO2, NULL) != 0){return 1;}
		pthread_join(no_thread,NULL);


		if(pthread_create(&nh_thread, NULL, &Composer_NH3, NULL) != 0){return 1;}
		pthread_join(nh_thread,NULL);
		sleep(sleep_time);//Required sleep time.
		
	}
	//Critical section of the main function ends
return 0;
}
