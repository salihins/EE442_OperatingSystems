//Inputs should be given as
//cpu1 burst_times, io1 burst_times, cpu2 burst_times, io2 burst_times, cpu3 burst_times, io3 burst_times
//However, code does not work. I could not figure it out. I just uploaded to get points as much as 
//I can. No disrespect intended.
//SRTF_scheduler and lottery_scheduler functions should work fine. But, I was not able to understand and implement
//Run thread and scheduler() function. Hence, it does not work.

#include <stdio.h>
#include <signal.h>
#include <ucontext.h>
#include <stdlib.h>
#include <string.h>


#define STACK_SIZE 4096
#define arr_size 5
//Use 1 for RUNNING 
#define RUNNING 1
//Use 2 for READY
#define READY 2
//Use 3 for FINISHED
#define FINISHED 3
//Use 4 for TO_DO
#define TO_DO 4
//Use 5 for I_O
#define I_O 5

typedef struct ThreadInfo{
	//Define the variables of the thread.
	ucontext_t context;
	int state;
	int cpu1;
	int cpu2;
	int cpu3;
	int io1;
	int io2;
	int io3;
	int spent;

} ThreadInfo;
ThreadInfo* thread_arr[arr_size];
int* idx_ptr;
void scheduler(int * ind_ptr){
	int index = *ind_ptr;
	if(index != arr_size+10){
		thread_arr[index]->state = RUNNING;
	}
	print_info();
	printf("%d\n",index+1);
	if(index != arr_size+10){
		thread_arr[index]->spent++;
		//If the conditions are satisfied, then the thread should enter scheduler
		//Otherwise, it should either labeled as finished or go to I/O.
		if(thread_arr[index]->spent == thread_arr[index]->cpu1
		   || thread_arr[index]->spent == thread_arr[index]->cpu1 + thread_arr[index]->io1+thread_arr[index]->cpu2
		   || thread_arr[index]->spent == thread_arr[index]->cpu1 + thread_arr[index]->io1+thread_arr[index]->cpu2+ thread_arr[index]->io2+thread_arr[index]->cpu3){
			printf("\n");
			thread_arr[index]->state=I_O;
		}
		else{
			thread_arr[index]->spent++;//Increase the time spent on CPU
			thread_arr[index]->state = READY;		
		}
	}
	
}

//Lottery scheduler implementation
//Each thread has tickets that is proportional to its remaining cpu time
//Then, a lottery chooses a thread to execute
int lottery_scheduler(){
	int total_cpu_time = 0;
	int one_th_tot_cpu_time[arr_size];
		
	for(int i=0; i<5; i++){
		//Get the total cpu time of the all threads
		total_cpu_time += thread_arr[i]->cpu1+thread_arr[i]->cpu2+thread_arr[i]->cpu3;
		//Get the total cpu time of the threads separately
		one_th_tot_cpu_time[i] = thread_arr[i]->cpu1+thread_arr[i]->cpu2+thread_arr[i]->cpu3;
	}
	//Create the array for tickets
	int selection[total_cpu_time];

	for (int j=0; j<5; j++){
		//Get the number of cpu time of the threads one by one.
		int counter = one_th_tot_cpu_time[j];
		for (int k=0;k<counter;k++){
			//Place the tickets			
			selection[k] = j;		
		}
	}
	//Choose a random number between [0,total_cpu_time)
	int picker = rand() %  total_cpu_time;
	//return the index of the winner thread
	return selection[picker];		
	}

//SRTF scheduler implementation
int SRTF_scheduler(){
	int total_cpu_time = 0;
	int index = arr_size + 10; //Choose a random number that will not cause a problem
	int initial_checker = 100000000;//Create a variable to check the condition
	for(int i=0; i<arr_size;i++){
		if(thread_arr[i]->state==2){
			//Get the total cpu time of the thread
			total_cpu_time += thread_arr[i]->cpu1+thread_arr[i]->cpu2+thread_arr[i]->cpu3;
		}
		//Calculate the remaining cpu time of the thread
		total_cpu_time -= thread_arr[i]->spent;
		//Check which one of the threads has the least remaining time
		if(total_cpu_time<initial_checker){
			initial_checker = total_cpu_time;
			index=i;
		}	
	}
	//return the index of the thread with shortest remaining time
	return index;
}



void initializeThread(int index,int cpu1, int cpu2, int cpu3, int io1, int io2, int io3){
	//Assign the input variables.	
	thread_arr[index]->state = TO_DO;
	thread_arr[index]->cpu1 = cpu1;
	thread_arr[index]->cpu2 = cpu2;
	thread_arr[index]->cpu3 = cpu3;
	thread_arr[index]->io1 = io1;
	thread_arr[index]->io2 = io2;
	thread_arr[index]->io3 = io3;
}

int createThread(int index, void * sm){
	int isFull=0;
	for(int i=0;i<arr_size;i++){
		if(thread_arr[i]->state != TO_DO){
			isFull += 1;		
		}	
	}
	if(isFull==5){return -1;}//return if the number of threads are 5.
	//Taken from homework manual.
	getcontext(&thread_arr[index]->context);
	thread_arr[index]->context.uc_link= &thread_arr[0]->context;
	thread_arr[index]->context.uc_stack.ss_sp = malloc(STACK_SIZE);
	thread_arr[index]->context.uc_stack.ss_size = STACK_SIZE;
	makecontext(&thread_arr[index]->context,(void (*)(void))scheduler,1,idx_ptr);
	thread_arr[index]->state = READY;
	return 0;
}

void runThread(int signal){
	int index = arr_size+10; //Choose an initial value that will not cause a problem.
	index = lottery_scheduler();

	getcontext(&thread_arr[0]->context);
	int* idx_ptr = (int*)malloc(sizeof(index));
	*idx_ptr = index;
	if(index==arr_size+10){
		for(int i=0;i<arr_size;i++){
			if(thread_arr[i]->state != FINISHED){
				index = i;			
			}	 	
		}	
	}
	if(index == arr_size+10){
		index=0;
	}
	makecontext(&thread_arr[index]->context,(void(*)(void))scheduler,1,idx_ptr);
	swapcontext(&thread_arr[0]->context,&thread_arr[index]->context);
	free(idx_ptr);
}

void print_info(void){
	//Print the information of the threads.
	int comma = 0;
	printf("running>");	
	for(int i=0; i<arr_size;i++){
		if(thread_arr[i]->state == RUNNING){
			printf("T%d",i+1);
			break;
		}	
	}
	printf("\tready>");
	for(int i=0; i<arr_size;i++){
		if(thread_arr[i]->state == READY){
			printf("T%d",i+1);
			if(comma ==1){printf(",");}
			comma = 1;
		
		}	
	}

	printf("\tfinished>");
	comma = 0;
	for(int i=0; i<arr_size;i++){
		if(thread_arr[i]->state == FINISHED){
			printf("T%d",i+1);
			if(comma ==1){printf(",");}
			comma = 1;
		}	
	}

	printf("\tIO>");
	comma = 0;
	for(int i=0; i<arr_size;i++){
		if(thread_arr[i]->state == I_O){
			printf("T%d",i+1);
			if(comma ==1){printf(",");}
			comma = 1;
		}	
	}
	printf("\n");
}



void exitThread(int index){
	//free the thread.
	free(thread_arr[index]->context.uc_stack.ss_sp);
}


int main(int argc, char* argv[]){
	for(int i=0;i<arr_size;i++){
		thread_arr[i] = (struct ThreadInfo *)malloc(sizeof(struct ThreadInfo));	
	}
	//get the inputs.
	for(int i=0;i<arr_size;i++){
		initializeThread(i,atoi(argv[i+1]),atoi(argv[i+11]),atoi(argv[i+21]),atoi(argv[i+6]),atoi(argv[i+16]),atoi(argv[i+26]));	
	}
	
//valgrind ./a.out 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 -g
	return 0;
}
